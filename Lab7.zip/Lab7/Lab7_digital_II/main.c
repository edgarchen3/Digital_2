
//*****************************************************************************
//
// blinky.c - Simple example to blink the on-board LED.
//
// Copyright (c) 2012-2020 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
//
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
//
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
//
// This is part of revision 2.2.0.295 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************


#include <stdint.h>
#include <stdbool.h>
#include "inc/tm4c123gh6pm.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/timer.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "driverlib/debug.h"
#include "driverlib/adc.h"

#define XTAL 16000000       //Reloj a 16MHz

//Variables
int i;

//Prototypes
void setup(void);
void delay(int mSeconds);

//Main

int main(void) {
    setup();

    if (GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0) {
        while((GPIO_PORTF_BASE, GPIO_PIN_4) == 0); //Anti bouncing
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIO_PIN_3);  //LED green on
        delay(3000); //delay of 3s
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0);           //LED green off
        delay(200); //delay of 200ms
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIO_PIN_3); //LED green flashing
        delay(200);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0);
        delay(200);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIO_PIN_3);
        delay(200);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0);
        delay(200);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIO_PIN_3);
        delay(200);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0);

        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3 | GPIO_PIN_1, GPIO_PIN_3 | GPIO_PIN_1);    //LED yellow on
        delay(3000); //delay of 3s
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3 | GPIO_PIN_1, 0);                          //LED yellow off

        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, GPIO_PIN_1);                              //LED red on
        delay(3000);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0);                                       //LED red off
    }

}


void setup(void) {
    SysCtlClockSet(SYSCTL_SYSDIV_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ | SYSCTL_OSC_MAIN); //Clock at 40MHz (first argument is used to change the frequency)
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);                                            //Enabling F port
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF));                                     //Waiting for the port to be initialized
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);           //LEDs as outputs
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, 0);                 //LEDs start off
    GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, GPIO_PIN_4);                                      //Push 1 as input
    GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_4, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);//Enabling pull up in push1
}

void delay(int mSeconds) {
    for (i = 0; i < mSeconds; i++) {
        SysTickDisable();                                   //Disabling SysTick
        SysTickPeriodSet(40000-1);                          //Defining period of 1 second
        SysTickEnable();                                    //Starting the period
        while((NVIC_ST_CTRL_R & NVIC_ST_CTRL_COUNT) == 0);  //Waiting until the cycle is finished
    }
}









