

/**
 * main.c
 */


#include <stdint.h>
#include <stdbool.h>
#include "inc/tm4c123gh6pm.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"

#define XTAL 16000000

//Definition of variables
int i;
uint32_t ui32Period;

//Definition of functions
void setup(void);
void delay(uint32_t msec);
void delay1ms(void);
void InitUART(void);
void UARTIntHandler(void);

int main(void)
{

    setup();

    while(1){
        //Toggle of blue LED
       /*GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, 0); //Turning off all the leds

        delay(500); //delay 500ms

        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3); //Turning on all the leds

        delay(500);*/ //delay 500ms

       /*UARTCharPut(UART0_BASE, 'H');
       UARTCharPut(UART0_BASE, 'o');
       UARTCharPut(UART0_BASE, 'l');
       UARTCharPut(UART0_BASE, 'a');
       UARTCharPut(UART0_BASE, ' ');
       UARTCharPut(UART0_BASE, 'M');
       UARTCharPut(UART0_BASE, 'u');
       UARTCharPut(UART0_BASE, 'n');
       UARTCharPut(UART0_BASE, 'd');
       UARTCharPut(UART0_BASE, 'o');
       UARTCharPut(UART0_BASE, 10);
       UARTCharPut(UART0_BASE, 13);*/


    }
    return 0;
}


void setup(void){
    SysCtlClockSet(SYSCTL_SYSDIV_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ | SYSCTL_OSC_MAIN); //Clock at 40MHz (first argument is used to change the frequency)
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);                                            //Enabling F port
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);           //LEDs as outputs
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);                                           //Enabling Timer 0
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER0));
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);                                        //Periodic
    ui32Period = (SysCtlClockGet()) / 2;                                                    //Defining the period
    TimerLoadSet(TIMER0_BASE, TIMER_A, ui32Period - 1);                                     //Configuring subTimer A and B
    TimerLoadSet(TIMER0_BASE, TIMER_B, ui32Period - 1);
    IntEnable(INT_TIMER0A);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMB_TIMEOUT);
    IntMasterEnable();
    TimerEnable(TIMER0_BASE, TIMER_A);
    TimerEnable(TIMER0_BASE, TIMER_B);

    InitUART();

}

void delay(uint32_t msec)
{
    //For cycle for determining the required delay time
    for (i = 0; i < msec; i++)
    {
        delay1ms();
    }
}

void delay1ms(void)
{
    //Making a delay of 1ms
    SysTickDisable();
    SysTickPeriodSet(40000-1);
    SysTickEnable();

    while ((NVIC_ST_CTRL_R & NVIC_ST_CTRL_COUNT) == 0);
}

void Timer0IntHandler(void)
{
    // Clear the timer interrupt
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    // Read the current state of the GPIO pin and
    // write back the opposite state

    /*if (GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_2))
    {
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, 0);
    }
    else
    {
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, 4);
    }*/
}


void InitUART(void)
{
    /*Enable the GPIO Port A*/
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    /*Enable the peripheral UART Module 0*/
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    /* Make the UART pins be peripheral controlled. */
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    GPIOPinConfigure(GPIO_PA0_U0RX); // RX
    GPIOPinConfigure(GPIO_PA1_U0TX); // TX

    /* Sets the configuration of a UART. */
    UARTConfigSetExpClk(
            UART0_BASE, SysCtlClockGet(), 115200,
            (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));

    IntEnable(INT_UART0); //Enabling interruptions
    UARTIntEnable(UART0_BASE, UART_INT_RX | UART_INT_RT); //Enabling interruptions for sending and receiving
    UARTEnable(UART0_BASE); //Initializing UART
}

void UARTIntHandler(void){
    char cReceived; //Saving the data
    UARTIntClear(UART0_BASE, UART_INT_RX | UART_INT_RT); //Cleaning flags
    while(UARTCharsAvail(UART0_BASE)) //While there is something in the channel
        {
            cReceived = UARTCharGetNonBlocking(UART0_BASE); //Saving the data
            UARTCharPutNonBlocking(UART0_BASE, cReceived); //Returns the data to the sender
        }
    if (cReceived == 'r'){ //If the char is an r
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_1) ^ GPIO_PIN_1); //Toggle of red led
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, 0); //Turning off blue LED
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0); //Turning off green LED
    }
    else if (cReceived == 'b'){ //If the char is an b
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_2) ^ GPIO_PIN_2);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0);
    }
    else if (cReceived == 'g'){ //If the char is an g
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, 0);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_3) ^ GPIO_PIN_3);
    }
}
